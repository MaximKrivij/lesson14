<?php

class Write
{
    private $_csv_file = null;

    /**
     * @param string $csv_file  - путь до csv-файла
     */
    public function __construct($_csv_file) {
        if (file_exists($_csv_file)) { //Если файл существует
            $this->_csv_file = $_csv_file; //Записываем путь к файлу в переменную
        }
        else { //Если файл не найден то вызываем исключение
            die("Файл  не найден");
        }
    }

    public function setCSV( $csv) {

        $handle = fopen($this->_csv_file, "a+");

        foreach ($csv as $value) { //Проходим массив
            //Записываем, 3-ий параметр - разделитель поля
            fputcsv($handle,$value );
        }

        fclose($handle); //Закрываем
    }
}