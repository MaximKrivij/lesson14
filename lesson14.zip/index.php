<?php
require_once 'Read.php';
require_once 'Write.php';

print <<<Doc
<html lang="">
<head><title>TITTLE</title></head>
    <body>
         <form action=" " method="POST">
             <input type="text" name="name" placeholder="Введите Имя:">
             <input type="date" name="date">
             <input type="submit" name="submit"value="Записать в файл">
         </form>    
    </body>
</html>
Doc;

$set_content = new Write('data.csv');
$get_content = new Read('data.csv');
$arr = $get_content->getCSV();

foreach ($arr as $value) {
    echo'<br>Имя:',$value[0],'&nbsp','День рождения:',$value[1],'<br>';
}

if(isset($_POST['submit'])) {
    if(!empty($_POST['name']) && !empty($_POST['date'])){
              $SendArr= [
                  [
                      '0'=>$_POST['name'],
                      '1'=>$_POST['date']]];

        $set_content->setCSV($SendArr);


    }else {
        echo 'Введите имя и дату рождения!<br>';
    }
}
